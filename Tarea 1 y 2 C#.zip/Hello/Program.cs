﻿// See https://aka.ms/new-console-template for more information

string entrada = "";
Console.WriteLine("Introduce tu nombre: ");
entrada = Console.ReadLine();
Console.WriteLine("El nombre es:  " + entrada);

Console.WriteLine("Introduce la hora: ");
entrada = Console.ReadLine();
Console.WriteLine("La hora es " + entrada);
