﻿// See https://aka.ms/new-console-template for more information
using Sesion5;
Ejercicios cls = new Ejercicios();
Lenguajes leng = new Lenguajes();
bool Salir = true;
string sMenu = "n";

//Ejecircio #1
Console.WriteLine("EJERCICIO #1");
Console.WriteLine("");
while (Salir) 
{ 
 cls = cls.IngresarCliente();
 cls.MostrarInformacion();

 Console.WriteLine("");
 Console.WriteLine("¿Desea ingresar otro cliente? (S/N):");
 sMenu = Console.ReadLine();

Salir = (sMenu.Equals("s", StringComparison.OrdinalIgnoreCase));
}

//Ejecircio #2
Console.WriteLine("");
Console.WriteLine("");
Console.WriteLine("EJERCICIO #2");
Console.WriteLine("");
leng.Menu();