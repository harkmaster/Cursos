﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace Sesion5
{
    public struct Lenguaje
    {
        public string Nombre;
        public string HolaMundo;
    }

    public class Lenguajes 
    {
        Lenguaje[] LenguajeLst;

        private void DefinirLenguajes()
        {
            LenguajeLst = new Lenguaje[7];

            LenguajeLst[0].Nombre = "C#";
            LenguajeLst[0].HolaMundo = "Console.WriteLine(\"Hola mundo\");";

            LenguajeLst[1].Nombre = "PHP";
            LenguajeLst[1].HolaMundo = "echo \"Hola mundo\"; ";

            LenguajeLst[2].Nombre = "JAVA";
            LenguajeLst[2].HolaMundo = "System.out.println(\"Hola mundo\"); ";

            LenguajeLst[3].Nombre = "VISUAL BASIC";
            LenguajeLst[3].HolaMundo = "Console.WriteLine(\"Hola mundo\")";

            LenguajeLst[4].Nombre = "HTML";
            LenguajeLst[4].HolaMundo = "document.write(\"Hola mundo\");";

            LenguajeLst[5].Nombre = "R";
            LenguajeLst[5].HolaMundo = "print(\"Hola mundo\")";

            LenguajeLst[6].Nombre = "PHYTON";
            LenguajeLst[6].HolaMundo = "print(\"Hola mundo\")";

        }

        private void PintarMenu() 
        {
            
            Console.WriteLine("");
            Console.WriteLine("SELECCIONE UN LENGUAJE DE PROGRAMACIÓN");
            Console.WriteLine("");
            for (int i = 0; i < LenguajeLst.Count(); i++)
            {
                Console.WriteLine(i.ToString() + "-" + LenguajeLst[i].Nombre);
            }
            Console.WriteLine("");
        }

        public void Menu()
        {
            bool Salir = true;
            string sMenu = "n";
            DefinirLenguajes();

            while (Salir)
            {

                PintarMenu();
                Console.WriteLine("");
                Console.WriteLine("Elija el número correspondiente al lengauje que desea o N para salir");
                sMenu = Console.ReadLine();

                switch (sMenu)
                {
                    case "0":
                    case "1":
                    case "2":
                    case "3":
                    case "4":
                    case "5":
                    case "6":
                        Console.WriteLine("");
                        Console.WriteLine("El código en " + LenguajeLst[int.Parse(sMenu)].Nombre + ", es: " + LenguajeLst[int.Parse(sMenu)].HolaMundo);
                        Console.WriteLine("");
                        Console.WriteLine("");
                        Salir = true;
                        break;
                    case "n":
                        Salir = false;
                        break;
                    default:
                        Console.WriteLine("");
                        Console.WriteLine("El valor ingresado no es válido. Intente de nuevo.");
                        Console.WriteLine("");
                        Console.WriteLine("");
                        Salir = true;
                        break;
                }                
            }

        }

    }     



    public class Ejercicios
    {

        public string Nombre { get; set; }
        public string Email { get; set; }
        public bool TieneCupon { get; set; }
        public double Precio { get; set; }

        // Constructor

        // Constructor
       public Ejercicios()
       {        
       }

      public Ejercicios(string nombre, string email, bool tienecupon, double precio)
       {
           Nombre = nombre;
           Email = email;
           TieneCupon = tienecupon;
           Precio = precio;
       }

        private bool ValidarEmail(string email)
        {
            // Expresión regular para validar un correo electrónico
            string patron = @"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$";

            // Validar el formato del correo electrónico
            Regex regex = new Regex(patron);
            return regex.IsMatch(email);
        }


        public Ejercicios IngresarCliente()
        {
            Console.WriteLine("Ingrese el nombre:");
            string nombre = Console.ReadLine();
                       

            bool esCorreoValido = false;
            string email = "";
            while (!esCorreoValido)
            {
                Console.WriteLine("Ingrese el email:");
                email = Console.ReadLine();

                esCorreoValido = ValidarEmail(email);
                if (!esCorreoValido)
                {
                   Console.WriteLine("El email ingresado no es correcto. Intente nuevamente.");
                }
            }


            double precio = 0;
            bool esprecioValido = false;
            while (!esprecioValido)
            {
                Console.WriteLine("Ingrese el precio:");
                if (double.TryParse(Console.ReadLine(), out precio))
                {
                    esprecioValido = true;
                }
                else
                {
                    Console.WriteLine("La estatura ingresada no es válida. Intente nuevamente.");
                }
            }

            Console.WriteLine("¿Tiene cupón? (S/N):");
            string sTieneCupon = Console.ReadLine();
            bool tienecupon = (sTieneCupon.Equals("s", StringComparison.OrdinalIgnoreCase));

            return new Ejercicios(nombre, email, tienecupon, precio);
        }

        public void MostrarInformacion()
        {
            Console.WriteLine(" ");
            Console.WriteLine("LOS DATOS DEL CLIENTE SON: ");
            Console.WriteLine("Nombre: " + Nombre);
            Console.WriteLine("Apellido: " + Email);
            Console.WriteLine("Precio: " + Precio);
            Console.WriteLine("¿Teien cupón?: " + (TieneCupon ? "SI" : "NO"));

            if (TieneCupon)
                Console.WriteLine("El precio final aplicando un 20% de descuento es: " + (Precio-((Precio*20)/100)).ToString() );
            else
                Console.WriteLine("El precio sin descuento es: " + Precio.ToString());
        }
    }

}
