﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sesion3
{

    public struct Cliente
    {
        public string NombreCompleto;
        public string Telefono;
        public string Direccion;
        public string Email;
        public bool EsNuevoCliente;
    }


    public class AgregarCliente
    {

        public void ObtenerDatosClienteDesdeConsola(ref Cliente cliente)
        {
            
            Console.WriteLine("Ingrese los datos del cliente:");

            Console.Write("Nombre completo: ");
            cliente.NombreCompleto = Console.ReadLine();

            Console.Write("Teléfono: ");
            cliente.Telefono = Console.ReadLine();

            Console.Write("Dirección: ");
            cliente.Direccion = Console.ReadLine();

            Console.Write("Email: ");
            cliente.Email = Console.ReadLine();

            Console.Write("¿Es nuevo cliente? (Sí/No): ");
            string esNuevoClienteStr = Console.ReadLine();
            cliente.EsNuevoCliente = (esNuevoClienteStr.ToLower() == "sí" || esNuevoClienteStr.ToLower() == "si");
        }

        public void MostrarDatosCliente(Cliente cliente)
        {
            Console.WriteLine(" ");
            Console.WriteLine("Información del cliente:");
            Console.WriteLine("Nombre completo: " + cliente.NombreCompleto);
            Console.WriteLine("Teléfono: " + cliente.Telefono);
            Console.WriteLine("Dirección: " + cliente.Direccion);
            Console.WriteLine("Email: " + cliente.Email);
            Console.WriteLine("¿Es nuevo cliente?: " + (cliente.EsNuevoCliente ? "Sí" : "No"));
        }
    }
}
