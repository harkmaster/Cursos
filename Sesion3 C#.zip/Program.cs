﻿using Sesion3;

Cliente cliente = new Cliente();
AgregarCliente cls = new AgregarCliente();

cls.ObtenerDatosClienteDesdeConsola(ref cliente);
cls.MostrarDatosCliente(cliente);