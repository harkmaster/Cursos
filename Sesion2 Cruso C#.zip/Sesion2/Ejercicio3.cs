﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Solución al ejecicio #3
namespace Sesion2
{
    internal class Ejercicio3
    {

        public double Numero { get; set; }
        public string Caracter { get; set; }
        public bool Valor1 { get; set; }
        public bool Valor2 { get; set; }

        // Constructor
        public Ejercicio3(double numero, string caracter, bool valor1, bool valor2)
        {
            Numero = numero;
            Caracter = caracter;
            Valor1 = valor1;
            Valor2 = valor2;
        }

        //Validar si un número sea mayor a 18
        public string EsMayor18()
        {
           return this.Numero > 18 ? "El número es mayor que 18" : "El número es menor o igual a 18";
        }

        //Validar si el valor de una cadena es caracter
        public string EsCaracter()
        {
            char caracter;
            bool esCaracter = char.TryParse(this.Caracter, out caracter);
            return esCaracter == true ? "El valor indicado es un caracter" : "El valor indicado no es un caracter";
        }

        public string SeCumplenCondiones()
        {
            string mensaje = "";
            if (this.Valor1 == true && this.Valor2 == true) { mensaje = "Se cumple que ambas condiciones son verdaderas"; }
            else if ((this.Valor1 == true && this.Valor2 == false) || (this.Valor1 == false && this.Valor2 == true)) 
            {
                mensaje = "Se cumple que el valor1 es: " + Valor1.ToString() + " y el valor2 es:" + Valor2.ToString(); 
            }
            else { mensaje = "No se cumple ninguna de las condiciones establecidas"; }

            return mensaje;

        }



    }
}
