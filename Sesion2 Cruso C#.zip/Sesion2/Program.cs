﻿// See https://aka.ms/new-console-template for more information
using Sesion2;

//Ejercicio #1
Persona pers = Persona.IngresarPersona();

pers.MostrarInformacion();



//Prueba de Ejercicio #3
/*Ejercicio3 eje = new Ejercicio3 (5, "#12",  false, false);

Console.WriteLine(eje.EsMayor18());
Console.WriteLine(eje.EsCaracter());
Console.WriteLine(eje.SeCumplenCondiones());*/