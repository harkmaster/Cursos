﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Solución al ejecicio #1
namespace Sesion2
{
    public class Persona
    {
        // Atributos
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public int Edad { get; set; }
        public bool SabeProgramar { get; set; }
        public double Estatura { get; set; }

        // Constructor
        public Persona(string nombre, string apellido, int edad, bool sabeProgramar, double estatura)
        {
            Nombre = nombre;
            Apellido = apellido;
            Edad = edad;
            SabeProgramar = sabeProgramar;
            Estatura = estatura;
        }


        public static Persona IngresarPersona()
        {
            Console.WriteLine("Ingrese el nombre:");
            string nombre = Console.ReadLine();

            Console.WriteLine("Ingrese el apellido:");
            string apellido = Console.ReadLine();

            int edad=0;
            bool esEdadValida = false;
            while (!esEdadValida)
            {
                Console.WriteLine("Ingrese la edad:");
                if (int.TryParse(Console.ReadLine(), out edad))
                {
                    esEdadValida = true;
                }
                else
                {
                    Console.WriteLine("La edad ingresada no es válida. Intente nuevamente.");
                }
            }

            double estatura=0;
            bool esEstaturaValida = false;
            while (!esEstaturaValida)
            {
                Console.WriteLine("Ingrese la estatura:");
                if (double.TryParse(Console.ReadLine(), out estatura))
                {
                    esEstaturaValida = true;
                }
                else
                {
                    Console.WriteLine("La estatura ingresada no es válida. Intente nuevamente.");
                }
            }

            Console.WriteLine("¿Sabe programar? (SI/NO):");
            string sabeProgramarInput = Console.ReadLine();
            bool sabeProgramar = (sabeProgramarInput.Equals("si", StringComparison.OrdinalIgnoreCase));

            return new Persona(nombre, apellido, edad, sabeProgramar, estatura);
        }

        public void MostrarInformacion()
        {
            Console.WriteLine(" " );
            Console.WriteLine("LOS DATOS DE LA PERSONA SON: ");
            Console.WriteLine("Nombre: " + Nombre);
            Console.WriteLine("Apellido: " + Apellido);
            Console.WriteLine("Edad: " + Edad);
            Console.WriteLine("Estatura: " + Estatura + "m");
            Console.WriteLine("Sabe programar: " + (SabeProgramar ? "SI" : "NO"));
        }

    }
}
