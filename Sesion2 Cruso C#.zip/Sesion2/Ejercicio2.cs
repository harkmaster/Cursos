﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Solución al ejecicio #2
namespace Sesion2
{
    public class Coche
    {
        // Atributos
        public int Puertas { get; set; }
        public int Ruedas { get; set; }
        public string Marca { get; set; }
        public bool ITVVigente { get; set; }

        // Constructor
        public Coche(int puertas, int ruedas, string marca, bool itvVigente)
        {
            Puertas = puertas;
            Ruedas = ruedas;
            Marca = marca;
            ITVVigente = itvVigente;
        }
    }

    public class Mesa
    {
        // Atributos
        public double Peso { get; set; }
        public double Largo { get; set; }
        public string Material { get; set; }
        public string Color { get; set; }

        // Constructor
        public Mesa(double peso, double largo, string material, string color)
        {
            Peso = peso;
            Largo = largo;
            Material = material;
            Color = color;
        }
    }
}
