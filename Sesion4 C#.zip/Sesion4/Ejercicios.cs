﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using Console = Colorful.Console; //Instalar paquete Install-Package Colorful.Console


namespace Sesion4
{
    public class Ejercicios
    {

       /* public int Ancho { get; set; }

        public int Alto { get; set; }

        public bool Relleno { get; set; }*/

        //Resolución del ejercicio #1
        public void MultiplicarUnoDiez(ref int numero)
        {
            int contador = 0;
            bool esNumeroValido = false;
            while (!esNumeroValido)
            {
                Console.WriteLine("Ingrese el número a multiplicar:");
                if (int.TryParse(Console.ReadLine(), out numero))
                {
                    while (contador < 10)
                    {
                        Console.WriteLine("El resultado de " + numero.ToString() + " x " + (contador + 1).ToString() + " es: " + (numero * (contador + 1)).ToString());
                        contador = contador + 1;
                    }
                    break;
                }
                else
                {
                    Console.WriteLine("El número indicado no es válida. Intente nuevamente.");
                }
            }

        }

        //Resolución del ejercicio #2
        public void SignoNumero(ref int numero)
        {
            int contador = 0;
            bool esNumeroValido = false;
            bool esPositivo = false;
            int contadorPositivos = 0;
            int contadorNegativos = 0;


            do
            {
                Console.WriteLine("Ingrese el número a verificar:");
                if (int.TryParse(Console.ReadLine(), out numero))
                {

                    if (numero > 0)
                    {
                        esPositivo = true;
                        ++contadorPositivos;
                    }
                    else
                    {
                        esPositivo = false;
                        ++contadorNegativos;
                    }

                    Console.WriteLine("El número " + numero.ToString() + " es " + (esPositivo == true ? "Positivo" : "Negativo"));
                    Console.WriteLine("Cantidad de números positivos:" + contadorPositivos.ToString() + ", cantidad de números negativos:" + contadorNegativos.ToString());
                    contador = contador + 1;

                    Console.WriteLine("Si desea salir presione n, si desea ingresar otro número ingrese s.");
                    if (Console.ReadLine() == "n")
                    {
                        break;
                    }
                }
                else
                {
                    Console.WriteLine("El número indicado no es válida. Intente nuevamente.");
                }
            } while (!esNumeroValido);

        }

        public void DibujarRectangulo() 
        {
           int Alto = 0;
           int Ancho = 0;
           int Cantidad = 1;
           bool Relleno = false;
           bool esValido = false;

            while (!esValido)
            {
                Console.WriteLine("Ingrese el ancho:");
                if (int.TryParse(Console.ReadLine(), out Ancho))
                {
                    esValido = true;
                }
                else
                {
                    Console.WriteLine("El ancho indicado no es válido.");
                }
            }

            esValido = false;
            while (!esValido)
            {
                Console.WriteLine("Ingrese el alto:");
                if (int.TryParse(Console.ReadLine(), out Alto))
                {
                    esValido = true;
                }
                else
                {
                    Console.WriteLine("El alto indicado no es válido.");
                }
            }

            Console.WriteLine("Está relleno? (S/N):");
            string estaRelleno = Console.ReadLine();
            Relleno = (estaRelleno.Equals("s", StringComparison.OrdinalIgnoreCase));

            esValido = false;
            while (!esValido)
            {
                Console.WriteLine("Cuántos desea dibujar:");
                if (int.TryParse(Console.ReadLine(), out Cantidad))
                {
                    esValido = true;
                }
                else
                {
                    Console.WriteLine("La cantidad no es válida.");
                }
            }

            Console.WriteLine(" ");

            for (int i = 1; i <= Cantidad; i++)
            {

                for (int j = 0; j< Alto; j++)
                {                            
                    for (int k = 0; k < Ancho; k++)
                    {

                      if (Relleno == false)
                      {
                            if (j == 0 || j == Alto - 1 || k == 0 || k == Ancho - 1)
                            {
                         
                                Console.Write("*");
                            }
                            else Console.Write(" ");
                         
                        }
                      else Console.Write("*");
                    }
                    Console.WriteLine(" ");
                }

                Console.WriteLine(" ");
                Console.WriteLine(" ");
            }
        }

    }
}
