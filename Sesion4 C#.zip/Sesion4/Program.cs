﻿using Sesion4;

Ejercicios ej = new Ejercicios();
int Numero = 0;

Console.WriteLine("EJERCICIO 1 - MULTIPLICAR DE 1 A 10");
ej.MultiplicarUnoDiez(ref Numero);
Console.WriteLine(" ");
Console.WriteLine(" ");
Console.WriteLine("EJERCICIO 2 - VALIDAR EL SIGNO");
Console.WriteLine(" ");
ej.SignoNumero(ref Numero);
Console.WriteLine(" ");
Console.WriteLine(" ");
Console.WriteLine("EJERCICIO 3 - DIBUJAR RECTÁNGULOS");
Console.WriteLine(" ");
ej.DibujarRectangulo();
